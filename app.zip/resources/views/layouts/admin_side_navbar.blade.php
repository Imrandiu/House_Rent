  <div class="panel panel-default">
            <nav id="sidebar">
             <ul class="list-unstyled components">
                <li> <a href="{{url('admin/home')}}"><i class="fa fa-university "></i> Dashboard</a> </li> 
                <li> <a href="{{url('admin/all_users')}}"><i class="fa fa-list-ul"></i>  Users</a> </li>
                <li> <a href="{{url('admin/all_posts')}}"><i class="fa fa-list-ul"></i>  Posts</a> </li>
                <li> <a href="{{url('admin/all_payment')}}"><i class="fa fa-list-ul"></i>  Payment</a> </li>
            </ul>
            </nav>
</div>