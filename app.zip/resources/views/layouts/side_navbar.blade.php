  <div class="panel panel-default">
            <nav id="sidebar">
             <ul class="list-unstyled components">
                <li> <a href="{{url('home')}}"><i class="fa fa-list-ul"></i> Your Post</a> </li> 
                      <li> <a href="{{url('give_payment')}}"><i class="fa fa-plus-circle"></i>  Give Payment</a> </li> 
                <li> <a href="{{url('give_post')}}"><i class="fa fa-plus-circle"></i>  Give Post</a> </li>
                <li> <a href="{{url('view_profile')}}"><i class="fa fa-university" aria-hidden="true"></i> Your Profile</a> </li> 
            </ul>
            </nav>
</div>